# Music Archive — Front-End + API

O ZIP enviado continha `frontend/` vazio, `backend/src/` sem código, `.env` vazio e `package.json` sem scripts de execução. Esta versão recompõe a estrutura, inclui uma interface responsiva e conecta o catálogo à API.

## Banco
1. Crie o banco PostgreSQL `music_archive`.
2. Execute `scripts/music arquive.sql` no Query Tool do pgAdmin.
3. Crie `backend/.env` copiando `backend/.env.example` e informe sua senha local.

## Back-End
```bash
cd backend
npm install
npm run dev
```
API: http://localhost:3000

## Front-End
Abra `frontend/index.html` no navegador ou use a extensão Live Server do VS Code. O catálogo consulta `GET http://localhost:3000/produtos`.

## Observações
- A sacola funciona no navegador; o fechamento de compra ainda precisa de identificação/autenticação do cliente e endereço para enviar `POST /pedidos`.
- O endpoint de pagamento apenas registra uma solicitação no banco; não processa cartão/PIX em gateway real.
- Não coloque credenciais reais no Git. O `.env` é ignorado.
